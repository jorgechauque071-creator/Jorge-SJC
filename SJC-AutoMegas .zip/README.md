# S.J.C Auto de Megas — app Android (liga ao bot-Jorge_SJC)

Pergunta ao bot, a cada 3 s, se há pedidos (`GET /pedidos/proximo`), faz a transferência pela Vodacom
e devolve o resultado (`POST /pedidos/resultado`). Segue o `docs/API_APP.md` do bot.

## 1. Compilar no GitHub (sem Android Studio)
1. Cria um repositório no GitHub e envia **o conteúdo desta pasta** (o ficheiro `build.gradle.kts` tem de ficar na raiz).
2. Vai ao separador **Actions** → *Build APK* (corre sozinho a cada envio; ou *Run workflow*).
3. Quando acabar (verde), abre a execução e descarrega **SJC-AutoMegas-apk** → dentro está o `.apk`.
4. Instala o APK no telemóvel (permite "instalar apps desconhecidas").

## 2. Configurar a app
- **Endereço do bot**: `http://IP:20236` (porta `CALLBACK_PORT` do `config.js`). O telemóvel tem de chegar a esse IP.
- **Token**: igual ao `APP_TOKEN` do `config.js`.
- **ID do telefone**: `tel1`, `tel2`… (um diferente por telefone; ajusta prioridade/limite com `.telefones` no bot).
- Toca em **Testar ligação ao bot** → tem de dizer "Ligação OK".
- Dá as permissões: chamadas/telefone/notificações, **acessibilidade** (liga "S.J.C Auto de Megas"),
  **sobrepor a outras apps** (para acender o ecrã) e **bateria sem restrições**.
- Escolhe o chip da Vodacom e toca em **Testar USSD**: tem de aparecer "Teste OK: saldo … MB".
- **INICIAR**. Desliga os dados móveis desse chip (usa Wi-Fi), senão o consumo do telemóvel mexe no saldo.

## 3. Como cada pedido é feito
1. Acende o ecrã e dispensa o bloqueio (telemóvel **sem senha**).
2. `*162#` → espera o menu → `8` → espera o menu → `2` → espera o ecrã "Quantos megas…" e **lê o saldo**.
3. Só escreve algo quando o menu esperado está aberto, com campo de texto; confirma o que escreveu antes de ENVIAR.
   Se o menu não for o esperado, não escreve nada e cancela.
4. Escreve a quantidade → espera "Digita o numero do recipiente" → escreve o número.
5. **Confirmação:** faz uma simulação (`*162#` → 8 → 2, lê "Saldo de dados") e **cancela**, duas vezes se preciso.
   - o saldo desceu o valor pedido → `ok`;
   - o saldo não mudou → **repete a transferência** (até 3 tentativas, dentro de ~140 s);
   - nada confirmado ou valor estranho → `verificar` (o bot não repete);
   - esgotou as tentativas e o saldo não mudou → `falhou` (o bot passa ao próximo telefone).
6. A mensagem da Vodacom nunca decide o resultado (ela já disse "não permitida" e enviou).

## 4. Limites
- Código **não compilado nem testado em aparelho** por quem o escreveu. Se o GitHub Actions falhar, copia o erro e envia.
- Se o telemóvel tiver senha/PIN, o ecrã não é desbloqueado.
- Os textos dos menus ("Servicos de Internet", "Transferir Megas", "Quantos megas", "numero do recipiente")
  estão em `VodacomFlows.kt`; se a Vodacom mudar as frases, ajusta lá.
- A app lê os SMS de pagamento recebido (M-Pesa/e-Mola) e envia o texto ao bot (`POST /sms`); o bot extrai o ID e o valor. Os SMS ficam numa fila e são reenviados se a net falhar.
- O limite diário do menu é também enviado ao bot (`POST /telefones/config`) ao iniciar o serviço.

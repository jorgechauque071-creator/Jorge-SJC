package mz.megabot

import android.content.Context
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reencaminha ao bot os SMS de pagamento recebido (M-Pesa / e-Mola): POST /sms {token, telefone, remetente, texto}.
 * O texto vai SEM alterações: quem o interpreta (ID e valor) é o bot.
 * Os SMS ficam guardados numa fila no telefone até o bot responder, para não se perderem se a net falhar.
 * Reenviar é seguro: o bot responde duplicado:true.
 */
object SmsForwarder {
    private const val PREFS = "sjc_sms_outbox"
    private const val KEY = "pending"
    private const val MAX_PENDING = 200
    private val lock = Any()
    private val flushing = AtomicBoolean(false)
    private val RE_RECEBIDO = Regex("receb(eu|este)", RegexOption.IGNORE_CASE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    /** Chamado pelo receiver para cada SMS novo. Ignora o que não é "Recebeu/Recebeste". */
    fun onSms(context: Context, sender: String, text: String) {
        if (!RE_RECEBIDO.containsMatchIn(text)) return
        val ctx = context.applicationContext
        add(ctx, sender, text)
        AppState.log("SMS de pagamento recebido de $sender; a enviar ao bot")
        flush(ctx)
    }

    fun hasPending(context: Context): Boolean = synchronized(lock) { load(context.applicationContext).length() > 0 }

    /** Tenta entregar tudo o que está na fila. Bloqueia (chamar fora da thread principal). */
    fun flush(context: Context) {
        val ctx = context.applicationContext
        if (!flushing.compareAndSet(false, true)) return
        try {
            Graph.init(ctx)
            val s = Graph.settings
            val base = BotLink.normalizeBase(s.serverUrl)
            val token = s.token.trim()
            if (base.isEmpty() || token.isEmpty()) return
            val url = (base + "/sms").toHttpUrlOrNull() ?: return

            val snapshot = synchronized(lock) { load(ctx) }
            for (i in 0 until snapshot.length()) {
                val item = snapshot.getJSONObject(i)
                val body = JSONObject()
                    .put("token", token)
                    .put("telefone", s.phoneId.trim())
                    .put("remetente", item.optString("remetente"))
                    .put("texto", item.getString("texto"))
                val done = try {
                    http.newCall(
                        Request.Builder().url(url)
                            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    ).execute().use { resp ->
                        when (resp.code) {
                            200 -> {
                                val j = try { JSONObject(resp.body?.string().orEmpty()) } catch (e: Exception) { JSONObject() }
                                if (j.optBoolean("ok")) {
                                    val dup = if (j.optBoolean("duplicado")) " (já registado)" else ""
                                    AppState.log("SMS ${j.optString("id")} — ${j.opt("valorMT")} MT enviado ao bot$dup")
                                } else {
                                    AppState.log("O bot não aceitou o SMS: ${j.optString("erro", "sem motivo")}")
                                }
                                true // o bot respondeu: não adianta repetir
                            }
                            401 -> { AppState.log("SMS por entregar: o bot recusou o token (401)"); false }
                            else -> { AppState.log("SMS por entregar: o bot respondeu HTTP ${resp.code}"); false }
                        }
                    }
                } catch (e: Exception) {
                    AppState.log("SMS por entregar (${e.message})")
                    false
                }
                if (done) remove(ctx, item.getString("uid")) else break // sem ligação: tenta tudo mais tarde
            }
        } finally {
            flushing.set(false)
        }
    }

    // ---------- fila no telefone ----------

    private fun load(ctx: Context): JSONArray {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return JSONArray()
        return try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
    }

    private fun save(ctx: Context, arr: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun add(ctx: Context, sender: String, text: String) = synchronized(lock) {
        val arr = load(ctx)
        arr.put(
            JSONObject().put("uid", UUID.randomUUID().toString())
                .put("remetente", sender).put("texto", text).put("ts", System.currentTimeMillis())
        )
        val out = JSONArray()
        val from = maxOf(0, arr.length() - MAX_PENDING)
        for (i in from until arr.length()) out.put(arr.get(i))
        save(ctx, out)
    }

    private fun remove(ctx: Context, uid: String) = synchronized(lock) {
        val arr = load(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("uid") != uid) out.put(arr.get(i))
        save(ctx, out)
    }
}

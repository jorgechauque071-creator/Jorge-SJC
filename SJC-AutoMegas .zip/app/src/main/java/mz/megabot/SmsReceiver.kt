package mz.megabot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Apanha cada SMS que chega ao telefone (funciona mesmo com a app fechada). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val sender = msgs[0].originatingAddress.orEmpty()
        val text = msgs.joinToString("") { it.messageBody.orEmpty() }
        val pending = goAsync()
        Thread {
            try {
                SmsForwarder.onSms(context, sender, text)
            } catch (e: Exception) {
                AppState.log("Erro ao tratar SMS: ${e.message}")
            } finally {
                pending.finish()
            }
        }.start()
    }
}

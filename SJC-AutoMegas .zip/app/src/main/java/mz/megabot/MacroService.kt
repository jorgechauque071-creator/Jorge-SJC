package mz.megabot

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Serviço em primeiro plano: mantém a ligação ao bot e processa as ordens, uma de cada vez. */
class MacroService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var link: BotLink? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Graph.init(applicationContext)
            Graph.settings.enabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notification("A iniciar…"),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
        )
        if (link == null) boot()
        return START_STICKY
    }

    private fun boot() {
        Graph.init(applicationContext)
        val settings = Graph.settings
        val cfg = TransferConfig(subscriptionId = settings.subscriptionId, dailyLimit = settings.dailyLimit)
        val flows = VodacomFlows(AccessibilitySessionFactory(applicationContext), cfg) { AppState.log(it) }
        val executor = TransferExecutor(flows, Graph.store, cfg) { o ->
            AppState.log("Pedido ${o.id}: ${o.status} — ${o.note}")
        }
        link = BotLink(scope, settings, Graph.store, executor) {
            checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        }.also { it.start() }

        // Reenvia ao bot os SMS que ficaram na fila (falha de net, bot em baixo...)
        scope.launch(Dispatchers.IO) {
            while (isActive) {
                try { if (SmsForwarder.hasPending(applicationContext)) SmsForwarder.flush(applicationContext) } catch (e: Exception) { AppState.log("SMS: ${e.message}") }
                delay(15_000)
            }
        }

        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sjc:service")
            .apply { setReferenceCounted(false); acquire() }

        AppState.serviceRunning.value = true
        AppState.log("Serviço iniciado")

        scope.launch {
            val nm = getSystemService(NotificationManager::class.java)
            AppState.conn.collect { c ->
                val text = when (c) {
                    Conn.ONLINE -> "Online — à espera de pedidos"
                    Conn.CONNECTING -> "A ligar ao bot…"
                    Conn.OFF -> "Desligado"
                }
                nm.notify(NOTIF_ID, notification(text))
            }
        }
    }

    override fun onDestroy() {
        link?.stop()
        link = null
        wake?.let { if (it.isHeld) it.release() }
        scope.cancel()
        AppState.serviceRunning.value = false
        AppState.log("Serviço parado")
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Estado do serviço", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, MacroService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("S.J.C Auto de Megas")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Parar", stop)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "mz.megabot.STOP"
        private const val CHANNEL = "sjc_service"
        private const val NOTIF_ID = 1
    }
}

/** Depois de reiniciar o telemóvel, volta a arrancar o serviço se estava ligado. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Graph.init(context)
        if (Graph.settings.enabled) {
            ContextCompat.startForegroundService(context, Intent(context, MacroService::class.java))
        }
    }
}

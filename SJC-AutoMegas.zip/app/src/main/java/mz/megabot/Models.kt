package mz.megabot

enum class OrderStatus { PENDING, EXECUTING, VERIFYING, DONE, FAILED, MANUAL }

val OrderStatus.isTerminal: Boolean
    get() = this == OrderStatus.DONE || this == OrderStatus.FAILED || this == OrderStatus.MANUAL

data class Order(
    val id: String,                    // ID único vindo do bot (idempotência)
    val recipient: String,
    val amountMb: Int,
    val status: OrderStatus = OrderStatus.PENDING,
    val attempts: Int = 0,
    val balanceBeforeMb: Int? = null,
    val balanceAfterMb: Int? = null,
    val note: String? = null,
    val reported: Boolean = false,     // resultado já entregue ao bot?
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
)

data class TransferConfig(
    val subscriptionId: Int,                       // chip usado (dual SIM); -1 = automático
    val minMb: Int = 100,
    val maxMb: Int = 10_240,
    val dailyLimit: Int = 10,                      // limite da Vodacom: 10x/dia
    val maxAttempts: Int = 3,
    val retryDelaysMs: List<Long> = listOf(5_000L, 10_000L),
    val stepTimeoutMs: Long = 25_000L,             // timeout por passo do USSD
    val verifyDelayMs: Long = 5_000L,              // espera antes de ler o saldo
    val verifyRecheckDelayMs: Long = 10_000L,      // segunda leitura se saldo não mudou
    // O bot desiste ao fim de 240 s (APP_ESPERA_RESULTADO_MS): não começar nova tentativa depois disto.
    val orderBudgetMs: Long = 140_000L,
    val toleranceMb: Int = 5,                      // ruído (consumo de dados do telemóvel)
    val recipientRegex: Regex = Regex("^8\\d{8}$"),
)

interface OrderStore {
    suspend fun get(id: String): Order?
    suspend fun insertIfAbsent(order: Order): Boolean   // false = ordem repetida
    suspend fun update(order: Order)
    suspend fun countToday(): Int                       // ordens que já tocaram na Vodacom hoje
    suspend fun unfinished(): List<Order>               // recuperar após crash/reinício
}

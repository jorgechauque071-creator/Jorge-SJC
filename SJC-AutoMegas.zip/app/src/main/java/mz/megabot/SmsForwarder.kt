package mz.megabot

import android.content.Context
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reencaminha ao bot dois tipos de SMS:
 *  - da operadora (remetente com letras, ex. "M-Pesa"): pagamento recebido → POST /sms {token, telefone, remetente, texto}
 *  - de um CLIENTE (remetente é um número de telefone) com o comprovativo → POST /sms/cliente {token, telefone, de, texto}
 * SMS de cliente NUNCA vão para /sms, para ninguém conseguir "fabricar" um pagamento.
 * O texto vai SEM alterações: quem o interpreta (ID e valor) é o bot.
 * Os SMS ficam guardados numa fila no telefone até o bot responder, para não se perderem se a net falhar.
 * Reenviar é seguro: o bot responde duplicado:true.
 */
object SmsForwarder {
    private const val PREFS = "sjc_sms_outbox"
    private const val KEY = "pending"
    private const val MAX_PENDING = 200
    private val lock = Any()
    private val flushing = AtomicBoolean(false)
    private val RE_RECEBIDO = Regex("receb(eu|este)", RegexOption.IGNORE_CASE)
    private val RE_COMPROVATIVO = Regex("confirmado|id\\s*trans|transferi(ste|u)", RegexOption.IGNORE_CASE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    /** Chamado pelo receiver para cada SMS novo. Ignora o que não é "Recebeu/Recebeste". */
    fun onSms(context: Context, sender: String, text: String, subId: Int = -1) {
        val ctx = context.applicationContext
        if (isPhoneNumber(sender)) {
            // SMS de um cliente: só interessa se parecer um comprovativo (senão ignora, sem responder)
            if (!RE_COMPROVATIVO.containsMatchIn(text)) return
            rememberSub(ctx, sender, subId)
            add(ctx, sender, text, "cliente")
            AppState.log("Comprovativo por SMS de $sender; a enviar ao bot")
        } else {
            if (!RE_RECEBIDO.containsMatchIn(text)) return
            add(ctx, sender, text, "operadora")
            AppState.log("SMS de pagamento recebido de $sender; a enviar ao bot")
        }
        flush(ctx)
    }

    /** Remetente que é um número de telefone (8+ dígitos); os da operadora têm letras ou códigos curtos. */
    private fun isPhoneNumber(sender: String): Boolean {
        val s = sender.trim()
        return s.count { it.isDigit() } >= 8 && s.all { it.isDigit() || it == '+' || it == ' ' || it == '-' }
    }

    // Chip em que o cliente escreveu, para responder pelo mesmo chip
    private fun rememberSub(ctx: Context, sender: String, subId: Int) {
        if (subId < 0) return
        ctx.getSharedPreferences("sjc_sms_sub", Context.MODE_PRIVATE).edit().putInt(sender.filter { it.isDigit() }.takeLast(9), subId).apply()
    }

    fun subFor(ctx: Context, number: String): Int =
        ctx.getSharedPreferences("sjc_sms_sub", Context.MODE_PRIVATE).getInt(number.filter { it.isDigit() }.takeLast(9), -1)

    fun hasPending(context: Context): Boolean = synchronized(lock) { load(context.applicationContext).length() > 0 }

    /** Tenta entregar tudo o que está na fila. Bloqueia (chamar fora da thread principal). */
    fun flush(context: Context) {
        val ctx = context.applicationContext
        if (!flushing.compareAndSet(false, true)) return
        try {
            Graph.init(ctx)
            val s = Graph.settings
            val base = BotLink.normalizeBase(s.serverUrl)
            val token = s.token.trim()
            if (base.isEmpty() || token.isEmpty()) return
            val urlOperadora = (base + "/sms").toHttpUrlOrNull() ?: return
            val urlCliente = (base + "/sms/cliente").toHttpUrlOrNull() ?: return

            val snapshot = synchronized(lock) { load(ctx) }
            for (i in 0 until snapshot.length()) {
                val item = snapshot.getJSONObject(i)
                val cliente = item.optString("tipo", "operadora") == "cliente"
                val url = if (cliente) urlCliente else urlOperadora
                val body = JSONObject()
                    .put("token", token)
                    .put("telefone", s.phoneId.trim())
                    .put("texto", item.getString("texto"))
                if (cliente) body.put("de", item.optString("remetente")) else body.put("remetente", item.optString("remetente"))
                val done = try {
                    http.newCall(
                        Request.Builder().url(url)
                            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    ).execute().use { resp ->
                        when (resp.code) {
                            200 -> if (cliente) {
                                AppState.log("Comprovativo de ${item.optString("remetente")} entregue ao bot")
                                true
                            } else {
                                val j = try { JSONObject(resp.body?.string().orEmpty()) } catch (e: Exception) { JSONObject() }
                                if (j.optBoolean("ok")) {
                                    val dup = if (j.optBoolean("duplicado")) " (já registado)" else ""
                                    AppState.log("SMS ${j.optString("id")} — ${j.opt("valorMT")} MT enviado ao bot$dup")
                                } else {
                                    AppState.log("O bot não aceitou o SMS: ${j.optString("erro", "sem motivo")}")
                                }
                                true // o bot respondeu: não adianta repetir
                            }
                            401 -> { AppState.log("SMS por entregar: o bot recusou o token (401)"); false }
                            else -> { AppState.log("SMS por entregar: o bot respondeu HTTP ${resp.code}"); false }
                        }
                    }
                } catch (e: Exception) {
                    AppState.log("SMS por entregar (${e.message})")
                    false
                }
                if (done) remove(ctx, item.getString("uid")) else break // sem ligação: tenta tudo mais tarde
            }
        } finally {
            flushing.set(false)
        }
    }

    // ---------- fila no telefone ----------

    private fun load(ctx: Context): JSONArray {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return JSONArray()
        return try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
    }

    private fun save(ctx: Context, arr: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun add(ctx: Context, sender: String, text: String, tipo: String) = synchronized(lock) {
        val arr = load(ctx)
        arr.put(
            JSONObject().put("uid", UUID.randomUUID().toString())
                .put("remetente", sender).put("texto", text).put("tipo", tipo).put("ts", System.currentTimeMillis())
        )
        val out = JSONArray()
        val from = maxOf(0, arr.length() - MAX_PENDING)
        for (i in from until arr.length()) out.put(arr.get(i))
        save(ctx, out)
    }

    private fun remove(ctx: Context, uid: String) = synchronized(lock) {
        val arr = load(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("uid") != uid) out.put(arr.get(i))
        save(ctx, out)
    }
}

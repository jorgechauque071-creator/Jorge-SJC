package mz.megabot

import android.content.Context
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reencaminha ao bot dois tipos de SMS:
 *  - da operadora (remetente com letras, ex. "M-Pesa"): pagamento recebido → POST /sms {token, telefone, remetente, texto}
 *  - de um CLIENTE (remetente é um número de telefone) com o comprovativo → POST /sms/cliente {token, telefone, de, texto}
 * SMS de cliente NUNCA vão para /sms, para ninguém conseguir "fabricar" um pagamento.
 * O texto vai SEM alterações: quem o interpreta (ID e valor) é o bot.
 * Os SMS ficam guardados numa fila no telefone até o bot responder, para não se perderem se a net falhar.
 * Reenviar é seguro: o bot responde duplicado:true.
 */
object SmsForwarder {
    private const val PREFS = "sjc_sms_outbox"
    private const val KEY = "pending"
    private const val MAX_PENDING = 200
    private val lock = Any()
    private val flushing = AtomicBoolean(false)
    private val RE_RECEBIDO = Regex("receb(eu|este)", RegexOption.IGNORE_CASE)
    private val RE_PAGAMENTO_OPERADORA = Regex(
        "confirmado\\s+\\w+\\.?\\s*recebeste|id\\s*trans\\s*:?\\s*[\\w.]+\\.?\\s*recebeu",
        RegexOption.IGNORE_CASE
    )
    private val RE_COMPROVATIVO = Regex(
        "confirmado|id\\s*trans|transferi(ste|u)" +
            "|[A-Za-z]{2}\\d{6}\\.?\\d{4}\\.?[A-Za-z]\\d{5}" +                                   // ID e-Mola sozinho
            "|\\b(?=[A-Za-z0-9]*\\d)(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{10,12}\\b",              // ID M-Pesa sozinho
        RegexOption.IGNORE_CASE
    )

    private val RE_CONFIRMA = Regex("confirmado|id\\s*trans", RegexOption.IGNORE_CASE)
    private val RE_MT = Regex("\\d\\s*mt\\b", RegexOption.IGNORE_CASE)
    private val RE_PALAVRAS = Regex("receb|pagamento|transfer", RegexOption.IGNORE_CASE)

    // Quanto tempo uma mensagem pode ficar na fila: pagamentos 24 h; comprovativos de clientes só 30 min (depois já não interessam)
    private const val MAX_AGE_OPERADORA_MS = 24 * 60 * 60 * 1000L
    private const val MAX_AGE_CLIENTE_MS = 30 * 60 * 1000L

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    /** Chamado pelo receiver para cada SMS novo. Ignora o que não é "Recebeu/Recebeste". */
    fun onSms(context: Context, sender: String, text: String, subId: Int = -1) {
        val ctx = context.applicationContext
        SmsInbox.markSeen(ctx, sender, text)
        AppState.log("SMS recebido de ${sender.ifBlank { "?" }} (${text.length} caracteres, chip $subId)")
        val operador = isOperatorSender(ctx, sender) || isOperatorName(sender)
        if (!operador && isPhoneNumber(sender)) {
            // SMS de um cliente: só interessa se parecer um comprovativo (senão ignora, sem responder)
            if (!RE_COMPROVATIVO.containsMatchIn(text)) {
                AppState.log("  ignorado: vem de um número e não parece um comprovativo")
                return
            }
            if (RE_PAGAMENTO_OPERADORA.containsMatchIn(text)) {
                AppState.log("  ATENÇÃO: veio de um número mas o texto parece SMS de pagamento da operadora. Se $sender for a M-Pesa/e-Mola, escreve-o em \"Remetentes da operadora\" no menu.")
            }
            rememberSub(ctx, sender, subId)
            add(ctx, sender, text, "cliente")
            AppState.log("  comprovativo de cliente: a enviar ao bot")
        } else {
            // M-Pesa / e-Mola: NUNCA se ignora nenhum SMS, vai tudo para o bot (é ele que o interpreta).
            // Outros remetentes (bancos, promoções, códigos...): só se o texto parecer um pagamento.
            if (!operador && !pareceDePagamento(text)) {
                AppState.log("  ignorado: remetente que não é M-Pesa/e-Mola e o texto não parece um pagamento")
                return
            }
            add(ctx, sender, text, "operadora")
            AppState.log("  SMS da operadora: a enviar ao bot")
        }
        flush(ctx)
    }

    /** O dono pode indicar remetentes (nomes ou números) que são mesmo a operadora. */
    private fun isOperatorSender(ctx: Context, sender: String): Boolean {
        return try {
            Graph.init(ctx)
            val digits = sender.filter { it.isDigit() }.takeLast(9)
            Graph.settings.operatorSenders.split(",").map { it.trim() }.filter { it.isNotEmpty() }.any { e ->
                e.equals(sender.trim(), ignoreCase = true) ||
                    (digits.length >= 8 && e.filter { it.isDigit() }.takeLast(9) == digits)
            }
        } catch (ex: Exception) {
            false
        }
    }

    /**
     * Teste app → bot: envia ao bot um SMS de M-Pesa e outro de e-Mola de MENTIRA (1 MT, ID aleatório) e diz se o bot
     * os leu. Não testa a chegada do SMS ao telemóvel, só o caminho app → bot. Bloqueia: chamar fora da thread principal.
     */
    fun selfTest(context: Context): String {
        val ctx = context.applicationContext
        Graph.init(ctx)
        val s = Graph.settings
        val base = BotLink.normalizeBase(s.serverUrl)
        val token = s.token.trim()
        if (base.isEmpty() || token.isEmpty()) return "Preenche primeiro o endereço e o token."
        val url = (base + "/sms").toHttpUrlOrNull() ?: return "Endereço inválido."
        val rnd = UUID.randomUUID().toString().replace("-", "").uppercase()
        val mpesaId = "T" + rnd.substring(0, 10)
        val emolaId = "PP261115.0000.T" + rnd.substring(10, 15)
        val mpesa = "Confirmado $mpesaId. Recebeste 1.00MT de 258840000000 - TESTE aos 15/11/26 as 7:27 AM. " +
            "O teu novo saldo M-Pesa e de 1.00MT. Em caso de duvida, liga 100. M-Pesa e facil!"
        val emola = "ID Trans: $emolaId. Recebeu 1.00MT de 870000000, TESTE as 07:27:00 15/11/2026. " +
            "Conteudo: teste. O seu novo saldo e de 1.00MT. Em caso de duvida, ligue para 100."

        fun enviar(nome: String, remetente: String, texto: String): String {
            val body = JSONObject().put("token", token).put("telefone", s.phoneId.trim())
                .put("remetente", remetente).put("texto", texto)
            return try {
                http.newCall(
                    Request.Builder().url(url).post(body.toString().toRequestBody("application/json".toMediaType())).build()
                ).execute().use { resp ->
                    val txt = resp.body?.string().orEmpty()
                    if (resp.code == 401) "$nome: o bot recusou o token"
                    else if (resp.code != 200) "$nome: o bot respondeu HTTP ${resp.code}"
                    else {
                        val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
                        if (j.optBoolean("ok")) "$nome: OK (o bot leu ${j.opt("valorMT")} MT)"
                        else "$nome: o bot não leu o SMS (${j.optString("erro", "sem motivo")})"
                    }
                }
            } catch (e: Exception) {
                "$nome: sem ligação ao bot (${e.message})"
            }
        }

        val r = enviar("M-Pesa", "M-PESA", mpesa) + " | " + enviar("e-Mola", "eMola", emola)
        AppState.log("Teste de SMS → $r")
        return "Teste de leitura: $r"
    }

    /** Remetente "M-PESA", "M-Pesa", "eMola", "e-Mola"...: vem da operadora, nunca se ignora. */
    private fun isOperatorName(sender: String): Boolean {
        val n = sender.lowercase().filter { it.isLetter() }
        return n.contains("mpesa") || n.contains("emola")
    }

    /** Para remetentes que não são M-Pesa/e-Mola: só interessa o que parece uma confirmação de pagamento. */
    private fun pareceDePagamento(text: String): Boolean =
        RE_CONFIRMA.containsMatchIn(text) || (RE_MT.containsMatchIn(text) && RE_PALAVRAS.containsMatchIn(text))

    /** Remetente que é um número de telefone (8+ dígitos); os da operadora têm letras ou códigos curtos. */
    private fun isPhoneNumber(sender: String): Boolean {
        val s = sender.trim()
        return s.count { it.isDigit() } >= 8 && s.all { it.isDigit() || it == '+' || it == ' ' || it == '-' }
    }

    // Chip em que o cliente escreveu, para responder pelo mesmo chip
    private fun rememberSub(ctx: Context, sender: String, subId: Int) {
        if (subId < 0) return
        ctx.getSharedPreferences("sjc_sms_sub", Context.MODE_PRIVATE).edit().putInt(sender.filter { it.isDigit() }.takeLast(9), subId).apply()
    }

    fun subFor(ctx: Context, number: String): Int =
        ctx.getSharedPreferences("sjc_sms_sub", Context.MODE_PRIVATE).getInt(number.filter { it.isDigit() }.takeLast(9), -1)

    fun hasPending(context: Context): Boolean = synchronized(lock) { load(context.applicationContext).length() > 0 }

    /**
     * Tenta entregar tudo o que está na fila. Bloqueia (chamar fora da thread principal).
     * Um SMS que falha NÃO bloqueia os outros: fica em espera (4 s, 8 s, 16 s... até 1 min) e passa-se ao seguinte.
     * Só pára tudo se não houver ligação ao bot.
     */
    fun flush(context: Context) {
        val ctx = context.applicationContext
        if (!flushing.compareAndSet(false, true)) return
        try {
            Graph.init(ctx)
            val s = Graph.settings
            val base = BotLink.normalizeBase(s.serverUrl)
            val token = s.token.trim()
            if (base.isEmpty() || token.isEmpty()) return
            val urlOperadora = (base + "/sms").toHttpUrlOrNull() ?: return
            val urlCliente = (base + "/sms/cliente").toHttpUrlOrNull() ?: return

            val agora = System.currentTimeMillis()
            val snapshot = synchronized(lock) { purge(ctx, agora) }
            for (i in 0 until snapshot.length()) {
                val item = snapshot.getJSONObject(i)
                if (item.optLong("next", 0L) > agora) continue   // falhou há pouco: espera a vez dele, os outros seguem
                val uid = item.getString("uid")
                val cliente = item.optString("tipo", "operadora") == "cliente"
                val url = if (cliente) urlCliente else urlOperadora
                val body = JSONObject()
                    .put("token", token)
                    .put("telefone", s.phoneId.trim())
                    .put("texto", item.getString("texto"))
                if (cliente) body.put("de", item.optString("remetente")) else body.put("remetente", item.optString("remetente"))

                var falha: String? = null      // motivo, se não entregou
                var semLigacao = false
                var codigo = -1
                var resposta = ""
                try {
                    http.newCall(
                        Request.Builder().url(url)
                            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                    ).execute().use { resp ->
                        codigo = resp.code
                        resposta = resp.body?.string().orEmpty()
                        Unit
                    }
                } catch (e: Exception) {
                    falha = "sem ligação ao bot (${e.message})"
                    semLigacao = true
                }

                if (!semLigacao) {
                    if (codigo == 200) {
                        if (cliente) {
                            AppState.log("Comprovativo de ${item.optString("remetente")} entregue ao bot")
                        } else {
                            val j = try { JSONObject(resposta) } catch (e: Exception) { JSONObject() }
                            if (j.optBoolean("ok")) {
                                val dup = if (j.optBoolean("duplicado")) " (já registado)" else ""
                                AppState.log("SMS ${j.optString("id")} — ${j.opt("valorMT")} MT enviado ao bot$dup")
                            } else {
                                AppState.log("O bot recebeu o SMS de ${item.optString("remetente")} mas não o reconheceu como pagamento (${j.optString("erro", "sem motivo")})")
                            }
                        }
                    } else if (codigo == 401) {
                        falha = "o bot recusou o token (401)"
                    } else {
                        falha = "o bot respondeu HTTP $codigo" + (if (codigo == 404) " (o bot não tem esta rota: está atualizado?)" else "")
                    }
                }

                if (falha == null) {
                    remove(ctx, uid)
                } else {
                    val tries = item.optInt("tries", 0) + 1
                    val teto = if (cliente) 5 * 60_000L else 60_000L
                    val espera = minOf(teto, 4_000L shl minOf(tries - 1, 6))
                    markFailed(ctx, uid, tries, System.currentTimeMillis() + espera)
                    if (tries == 1 || tries % 10 == 0) AppState.log("SMS por entregar (tentativa $tries): $falha")
                    if (semLigacao) break   // sem net / bot em baixo: não vale a pena tentar os outros agora
                }
            }
        } finally {
            flushing.set(false)
        }
    }

    // ---------- fila no telefone ----------

    private fun load(ctx: Context): JSONArray {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return JSONArray()
        return try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
    }

    private fun save(ctx: Context, arr: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun add(ctx: Context, sender: String, text: String, tipo: String) = synchronized(lock) {
        val arr = load(ctx)
        arr.put(
            JSONObject().put("uid", UUID.randomUUID().toString())
                .put("remetente", sender).put("texto", text).put("tipo", tipo).put("ts", System.currentTimeMillis())
        )
        val out = JSONArray()
        val from = maxOf(0, arr.length() - MAX_PENDING)
        for (i in from until arr.length()) out.put(arr.get(i))
        save(ctx, out)
    }

    private fun remove(ctx: Context, uid: String) = synchronized(lock) {
        val arr = load(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("uid") != uid) out.put(arr.get(i))
        save(ctx, out)
    }

    /** Tira da fila o que já não interessa e devolve a fila. Chamar com o lock. */
    private fun purge(ctx: Context, agora: Long): JSONArray {
        val arr = load(ctx)
        val out = JSONArray()
        var tirou = 0
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val idade = agora - item.optLong("ts", agora)
            val limite = if (item.optString("tipo", "operadora") == "cliente") MAX_AGE_CLIENTE_MS else MAX_AGE_OPERADORA_MS
            if (idade > limite) tirou++ else out.put(item)
        }
        if (tirou > 0) {
            save(ctx, out)
            AppState.log("$tirou SMS descartado(s) da fila por serem demasiado antigos")
        }
        return out
    }

    private fun markFailed(ctx: Context, uid: String, tries: Int, next: Long) = synchronized(lock) {
        val arr = load(ctx)
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            if (item.optString("uid") == uid) {
                item.put("tries", tries)
                item.put("next", next)
            }
        }
        save(ctx, arr)
    }
}

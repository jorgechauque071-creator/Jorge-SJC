package mz.megabot

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Definições guardadas cifradas (o token nunca fica em texto simples). */
class AppSettings(context: Context) {
    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "sjc_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        context.getSharedPreferences("sjc_plain", Context.MODE_PRIVATE)
    }

    /** Endereço do bot, ex.: http://192.168.1.10:20236 (CALLBACK_PORT do config.js). */
    var serverUrl: String
        get() = prefs.getString("url", "") ?: ""
        set(v) { prefs.edit().putString("url", v).apply() }

    /** Identificador deste telefone no bot: tel1, tel2, … */
    var phoneId: String
        get() = prefs.getString("phone", "tel1") ?: "tel1"
        set(v) { prefs.edit().putString("phone", v).apply() }

    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(v) { prefs.edit().putString("token", v).apply() }

    var subscriptionId: Int
        get() = prefs.getInt("sub", -1)
        set(v) { prefs.edit().putInt("sub", v).apply() }

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) { prefs.edit().putBoolean("enabled", v).apply() }
}

/** Ordens persistidas em SQLite: sobrevivem a crashes e reinícios. */
class SqliteOrderStore(context: Context) :
    SQLiteOpenHelper(context, "orders.db", null, 1), OrderStore {

    var onChanged: (() -> Unit)? = null
    private val mutex = Mutex()

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE orders(
                id TEXT PRIMARY KEY, recipient TEXT NOT NULL, amount_mb INTEGER NOT NULL,
                status TEXT NOT NULL, attempts INTEGER NOT NULL,
                balance_before INTEGER, balance_after INTEGER, note TEXT,
                reported INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private suspend fun <T> db(block: (SQLiteDatabase) -> T): T =
        withContext(Dispatchers.IO) { mutex.withLock { block(writableDatabase) } }

    private fun Cursor.toOrder() = Order(
        id = getString(0),
        recipient = getString(1),
        amountMb = getInt(2),
        status = OrderStatus.valueOf(getString(3)),
        attempts = getInt(4),
        balanceBeforeMb = if (isNull(5)) null else getInt(5),
        balanceAfterMb = if (isNull(6)) null else getInt(6),
        note = if (isNull(7)) null else getString(7),
        reported = getInt(8) == 1,
        createdAt = getLong(9),
        updatedAt = getLong(10),
    )

    private fun Order.toValues(now: Long) = ContentValues().apply {
        put("id", id); put("recipient", recipient); put("amount_mb", amountMb)
        put("status", status.name); put("attempts", attempts)
        put("balance_before", balanceBeforeMb); put("balance_after", balanceAfterMb)
        put("note", note); put("reported", if (reported) 1 else 0)
        put("created_at", createdAt); put("updated_at", now)
    }

    private fun queryOrders(d: SQLiteDatabase, where: String, args: Array<String>?, tail: String = ""): List<Order> =
        d.rawQuery("SELECT $COLS FROM orders $where $tail", args).use { c ->
            buildList { while (c.moveToNext()) add(c.toOrder()) }
        }

    override suspend fun get(id: String): Order? =
        db { d -> queryOrders(d, "WHERE id=?", arrayOf(id)).firstOrNull() }

    override suspend fun insertIfAbsent(order: Order): Boolean {
        val ok = db { d ->
            d.insertWithOnConflict("orders", null, order.toValues(System.currentTimeMillis()), SQLiteDatabase.CONFLICT_IGNORE) != -1L
        }
        if (ok) onChanged?.invoke()
        return ok
    }

    override suspend fun update(order: Order) {
        db { d -> d.insertWithOnConflict("orders", null, order.toValues(System.currentTimeMillis()), SQLiteDatabase.CONFLICT_REPLACE) }
        onChanged?.invoke()
    }

    override suspend fun countToday(): Int = db { d ->
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        d.rawQuery("SELECT COUNT(*) FROM orders WHERE attempts>0 AND created_at>=?", arrayOf(start.toString()))
            .use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    override suspend fun unfinished(): List<Order> =
        db { d -> queryOrders(d, "WHERE status NOT IN ('DONE','FAILED','MANUAL')", null, "ORDER BY created_at") }

    suspend fun unreported(): List<Order> =
        db { d -> queryOrders(d, "WHERE status IN ('DONE','FAILED','MANUAL') AND reported=0", null, "ORDER BY created_at") }

    suspend fun markReported(id: String) {
        db { d -> d.execSQL("UPDATE orders SET reported=1 WHERE id=?", arrayOf(id)) }
        onChanged?.invoke()
    }

    suspend fun recent(limit: Int = 50): List<Order> =
        db { d -> queryOrders(d, "", null, "ORDER BY created_at DESC LIMIT $limit") }

    private companion object {
        const val COLS = "id,recipient,amount_mb,status,attempts,balance_before,balance_after,note,reported,created_at,updated_at"
    }
}

package mz.megabot

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.WindowManager
import kotlinx.coroutines.delay

/**
 * Liga o ecrã e tira o ecrã de bloqueio (para telemóveis SEM senha/PIN) antes de cada USSD.
 * Se o telemóvel tiver senha, isto não consegue desbloquear — remove a senha.
 */
object ScreenWaker {
    private var lock: PowerManager.WakeLock? = null

    @Suppress("DEPRECATION")
    suspend fun ensureAwake(ctx: Context) {
        val app = ctx.applicationContext
        val pm = app.getSystemService(PowerManager::class.java)
        val km = app.getSystemService(KeyguardManager::class.java)

        synchronized(this) {
            val l = lock ?: pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "sjc:screen",
            ).also { it.setReferenceCounted(false); lock = it }
            l.acquire(4 * 60_000L)                         // renova enquanto houver trabalho
        }

        if (km.isKeyguardLocked || !pm.isInteractive) {
            try {
                app.startActivity(
                    Intent(app, WakeActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                )
            } catch (e: Exception) {
                AppState.log("Não consegui acordar o ecrã: ${e.message}")
            }
            repeat(20) {
                if (!km.isKeyguardLocked && pm.isInteractive) return
                delay(200)
            }
            AppState.log("Ecrã ainda bloqueado (tem senha? falta a permissão 'sobrepor a outras apps'?)")
        }
    }

    fun release() {
        synchronized(this) { lock?.let { if (it.isHeld) it.release() } }
    }
}

/** Atividade transparente que acende o ecrã, aparece sobre o bloqueio e dispensa-o. */
class WakeActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { finish() }
                override fun onDismissError() { finish() }
                override fun onDismissCancelled() { finish() }
            })
        } else {
            finish()
        }
        Handler(Looper.getMainLooper()).postDelayed({ if (!isFinishing) finish() }, 4_000)
    }
}

package mz.megabot

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay

/** Ponte entre o serviço de acessibilidade (lê o diálogo USSD) e as sessões (coroutines). */
object UssdBridge {
    @Volatile var service: UssdAccessibilityService? = null

    private var pending: CompletableDeferred<String>? = null
    private var stale: String? = null
    private var sawProgress = false

    @Synchronized
    fun expect(staleText: String?): CompletableDeferred<String> {
        stale = staleText
        sawProgress = false
        val d = CompletableDeferred<String>()
        pending = d
        return d
    }

    @Synchronized
    fun clear() {
        pending = null
    }

    @Synchronized
    fun onProgress() {
        sawProgress = true
    }

    @Synchronized
    fun onDialog(text: String) {
        val p = pending ?: return
        // Ignora o diálogo antigo que ainda está no ecrã logo a seguir a responder.
        if (!sawProgress && norm(text) == stale?.let { norm(it) }) return
        if (p.complete(text)) pending = null
    }

    fun norm(s: String): String = s.replace(Regex("\\s+"), " ").trim()
}

data class UssdScreen(val progress: Boolean, val text: String)

class UssdAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        UssdBridge.service = this
        AppState.log("Acessibilidade ligada")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        UssdBridge.service = null
        AppState.log("Acessibilidade desligada")
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return
        if (!isPhonePkg(e.packageName?.toString())) return
        val root = findDialogRoot() ?: return
        val screen = readScreen(root) ?: return
        if (screen.progress) UssdBridge.onProgress() else UssdBridge.onDialog(screen.text)
    }

    // ---------- leitura (só a janela do telefone; nunca outras apps) ----------

    private fun findDialogRoot(): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { if (isPhonePkg(it.packageName?.toString())) return it }
        return try {
            windows.asSequence().mapNotNull { it.root }.firstOrNull { isPhonePkg(it.packageName?.toString()) }
        } catch (e: Exception) {
            null
        }
    }

    /** Texto do menu USSD aberto agora (null = nenhum menu pronto; "a executar…" também dá null). */
    fun currentDialogText(): String? =
        findDialogRoot()?.let { readScreen(it) }?.takeIf { !it.progress }?.text

    /** O menu aberto tem campo de texto para escrever? */
    fun hasInput(): Boolean {
        val root = findDialogRoot() ?: return false
        return findFirst(root) { isEdit(it) } != null
    }

    private fun readScreen(root: AccessibilityNodeInfo): UssdScreen? {
        val texts = mutableListOf<String>()
        var hasButton = false
        fun walk(n: AccessibilityNodeInfo?) {
            n ?: return
            val cls = n.className?.toString().orEmpty()
            val id = n.viewIdResourceName.orEmpty()
            when {
                cls.endsWith("EditText") -> {}
                cls.endsWith("Button") || id == "android:id/button1" || id == "android:id/button2" -> hasButton = true
                cls.endsWith("TextView") -> n.text?.toString()?.takeIf { it.isNotBlank() }?.let { texts.add(it) }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (texts.isEmpty()) return null
        val joined = texts.joinToString("\n")
        val progress = PROGRESS_KEYS.any { joined.contains(it, ignoreCase = true) }
        if (!progress && !hasButton) return null
        return UssdScreen(progress, joined)
    }

    // ---------- ações ----------

    /** Escreve no campo do menu e confirma, lendo de volta, que ficou exatamente [text]. */
    fun setInputVerified(text: String): Boolean {
        val root = findDialogRoot() ?: return false
        val edit = findFirst(root) { isEdit(it) } ?: return false
        edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
        edit.refresh()
        return edit.text?.toString()?.trim() == text
    }

    fun clickPositive(): Boolean = clickButton(positive = true)

    /** Fecha o diálogo (CANCELAR; se só houver um botão, carrega nele). */
    fun cancelDialog(): Boolean = clickButton(positive = false)

    private fun clickButton(positive: Boolean): Boolean {
        val root = findDialogRoot() ?: return false
        val ids = if (positive) listOf("android:id/button1") else listOf("android:id/button2", "android:id/button1")
        val words = if (positive) POSITIVE else NEGATIVE + POSITIVE
        val target = ids.firstNotNullOfOrNull { id -> findFirst(root) { it.viewIdResourceName == id } }
            ?: words.firstNotNullOfOrNull { w ->
                findFirst(root) {
                    it.className?.toString()?.endsWith("Button") == true &&
                        it.text?.toString()?.trim().equals(w, ignoreCase = true)
                }
            } ?: return false
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun isEdit(n: AccessibilityNodeInfo) = n.className?.toString()?.endsWith("EditText") == true

    private fun findFirst(root: AccessibilityNodeInfo, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (pred(root)) return root
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            findFirst(c, pred)?.let { return it }
        }
        return null
    }

    private companion object {
        val PHONE_KEYS = listOf("phone", "telecom", "telephony", "incallui", "ussd")
        val PROGRESS_KEYS = listOf("a executar", "executando", "running ussd", "ussd code running", "executar código ussd")
        val POSITIVE = listOf("ENVIAR", "SEND", "OK", "CONFIRMAR", "ACEITAR")
        val NEGATIVE = listOf("CANCELAR", "CANCEL", "FECHAR", "DISMISS")
        fun isPhonePkg(pkg: String?) = pkg != null && PHONE_KEYS.any { pkg.contains(it) }
    }
}

/**
 * Sessão USSD real. Regra de ouro: só escreve quando o menu esperado está ABERTO e pronto
 * (com campo de texto), confirma o que escreveu e só então carrega em ENVIAR.
 */
class AccessibilityUssdSession(private val ctx: Context, private val subId: Int) : UssdSession {
    private var lastScreen: String? = null

    override suspend fun dial(code: String): String {
        val svc = UssdBridge.service ?: throw UssdException("Serviço de acessibilidade desligado")
        ScreenWaker.ensureAwake(ctx)                       // liga o ecrã e tira o ecrã de bloqueio
        svc.cancelDialog()                                 // fecha menu antigo, se existir
        waitUntil(3_000) { svc.currentDialogText() == null }
        delay(500)
        val next = UssdBridge.expect(null)
        placeCall(code)
        return next.await().also { lastScreen = it }
    }

    override suspend fun reply(text: String): String {
        val svc = UssdBridge.service ?: throw UssdException("Serviço de acessibilidade desligado")
        val expected = lastScreen ?: throw UssdException("Não há menu aberto para responder")

        // 1) Esperar que o menu esperado esteja mesmo no ecrã, com campo de texto.
        val ready = waitUntil(6_000) {
            svc.currentDialogText()?.let { UssdBridge.norm(it) == UssdBridge.norm(expected) } == true && svc.hasInput()
        }
        if (!ready) throw UssdException("O menu esperado ainda não está aberto — nada foi escrito")

        // 2) Escrever e confirmar que ficou escrito.
        val next = UssdBridge.expect(expected)
        if (!svc.setInputVerified(text)) {
            UssdBridge.clear()
            throw UssdException("Não consegui escrever no campo do menu")
        }
        delay(250)

        // 3) Rever que o menu continua o mesmo antes de enviar.
        if (svc.currentDialogText()?.let { UssdBridge.norm(it) } != UssdBridge.norm(expected)) {
            UssdBridge.clear()
            throw UssdException("O menu mudou antes de enviar")
        }
        if (!svc.clickPositive()) {
            UssdBridge.clear()
            throw UssdException("Botão ENVIAR não encontrado")
        }
        return next.await().also { lastScreen = it }
    }

    override suspend fun close() {
        UssdBridge.clear()
        UssdBridge.service?.cancelDialog()
    }

    private suspend fun waitUntil(timeoutMs: Long, cond: () -> Boolean): Boolean {
        var waited = 0L
        while (waited <= timeoutMs) {
            if (cond()) return true
            delay(150)
            waited += 150
        }
        return false
    }

    @SuppressLint("MissingPermission")
    private fun placeCall(code: String) {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        val extras = Bundle()
        findAccount(tm)?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
        try {
            tm.placeCall(Uri.fromParts("tel", code, null), extras)
        } catch (e: SecurityException) {
            throw UssdException("Sem permissão de chamadas (CALL_PHONE)", e)
        }
    }

    @SuppressLint("MissingPermission")
    private fun findAccount(tm: TelecomManager): PhoneAccountHandle? {
        if (subId < 0) return null
        val tel = ctx.getSystemService(TelephonyManager::class.java)
        return try {
            tm.callCapablePhoneAccounts.firstOrNull { tel.createForPhoneAccountHandle(it)?.subscriptionId == subId }
        } catch (e: SecurityException) {
            null
        }
    }
}

class AccessibilitySessionFactory(private val ctx: Context) : UssdSessionFactory {
    override fun newSession(subscriptionId: Int): UssdSession = AccessibilityUssdSession(ctx, subscriptionId)
}

package mz.megabot

import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.text.Normalizer
import kotlin.math.roundToInt

/**
 * Uma sessão USSD interativa. Cada chamada devolve o texto do ecrã que a Vodacom mostrou.
 * Lança UssdException em timeout, sessão cortada ou erro.
 */
interface UssdSession {
    suspend fun dial(code: String): String
    suspend fun reply(text: String): String
    suspend fun close()
}

interface UssdSessionFactory {
    fun newSession(subscriptionId: Int): UssdSession
}

class UssdException(message: String, cause: Throwable? = null) : Exception(message, cause)

sealed interface TransferOutcome {
    /** Falhou ANTES de enviar o número do destinatário: nada foi transferido, repetir é seguro. */
    data class NotSubmitted(val reason: String) : TransferOutcome

    /** O número foi enviado: o resultado real só se sabe pelo saldo. Nunca confiar em finalMessage. */
    data class Submitted(val finalMessage: String) : TransferOutcome

    /** A Vodacom mostrou "Atingiste o limite diario...": este cartão está cheio hoje e NADA foi enviado. Não repetir. */
    data class LimitReached(val message: String) : TransferOutcome
}

/** Resultado da leitura do saldo de dados. */
sealed interface BalanceRead {
    data class Mb(val mb: Int) : BalanceRead
    /** Em vez do saldo, a Vodacom mostrou a mensagem do limite diário de transferências. */
    object LimitReached : BalanceRead
    object Unknown : BalanceRead
}

class VodacomFlows(
    private val sessions: UssdSessionFactory,
    private val cfg: TransferConfig,
    private val trace: (String) -> Unit = {},      // recebe cada menu lido (para o registo)
) {
    /**
     * *162# → 8 → 2 → quantidade → número. Cada resposta só é escrita depois de o menu
     * anterior estar aberto e reconhecido; se o menu não for o esperado, aborta SEM escrever nada.
     * [onBalanceBefore] é chamado no ecrã da quantidade, antes do ponto sem retorno.
     */
    suspend fun submitTransfer(
        amountMb: Int,
        recipient: String,
        onBalanceBefore: suspend (Int) -> Unit,
    ): TransferOutcome {
        val s = sessions.newSession(cfg.subscriptionId)
        try {
            try {
                var screen = step("*162#") { s.dial("*162#") }
                seen("Menu 1", screen)
                expect(screen, "Servicos de Internet", "menu principal")

                screen = step("opção 8") { s.reply("8") }
                seen("Menu 2", screen)
                expect(screen, "Transferir Megas", "menu de internet")

                screen = step("opção 2") { s.reply("2") }
                seen("Menu 3", screen)
                if (isLimitScreen(screen)) {
                    trace("✗ Limite diário da Vodacom já atingido: não envio nada")
                    return TransferOutcome.LimitReached(screen.take(160))
                }
                expect(screen, "Quantos megas", "ecrã da quantidade")
                // Sem saldo visível não há como confirmar depois: não avança.
                val before = parseBalanceMb(screen)
                    ?: throw UssdException("saldo de dados não visível no ecrã da quantidade")
                noteBalance(before)
                onBalanceBefore(before)

                screen = step("quantidade") { s.reply(amountMb.toString()) }
                seen("Menu 4", screen)
                if (isLimitScreen(screen)) {
                    trace("✗ Limite diário da Vodacom atingido ao indicar a quantidade: não envio nada")
                    return TransferOutcome.LimitReached(screen.take(160))
                }
                expect(screen, "numero do recipiente", "pedido do número")
            } catch (e: UssdException) {
                trace("✗ Antes do envio: ${e.message}")
                return TransferOutcome.NotSubmitted(e.message ?: "erro USSD")
            }

            // ---- PONTO SEM RETORNO: a partir daqui a Vodacom pode debitar mesmo com erro ----
            val finalMessage = try {
                step("número") { s.reply(recipient) }
            } catch (e: UssdException) {
                "sem resposta: ${e.message}"
            }
            seen("Resposta", finalMessage)
            return TransferOutcome.Submitted(finalMessage)
        } finally {
            withContext(NonCancellable) { runCatching { s.close() } }
        }
    }

    /**
     * Simulação de transferência só para ver o saldo: *162# → 8 → 2 (ecrã que mostra
     * "Saldo de dados") e CANCELA sem escrever quantidade nem número.
     */
    suspend fun readBalanceMb(): Int? = (readBalance() as? BalanceRead.Mb)?.mb

    /** Como readBalanceMb, mas distingue "limite diário atingido" de "não consegui ler". */
    suspend fun readBalance(): BalanceRead {
        val s = sessions.newSession(cfg.subscriptionId)
        return try {
            var screen = step("*162#") { s.dial("*162#") }
            expect(screen, "Servicos de Internet", "menu principal (saldo)")
            screen = step("opção 8") { s.reply("8") }
            expect(screen, "Transferir Megas", "menu de internet (saldo)")
            screen = step("opção 2") { s.reply("2") }
            seen("Saldo", screen)
            if (isLimitScreen(screen)) {
                BalanceRead.LimitReached
            } else {
                val mb = parseBalanceMb(screen)
                if (mb != null) {
                    noteBalance(mb)
                    BalanceRead.Mb(mb)
                } else {
                    BalanceRead.Unknown
                }
            }
        } catch (e: UssdException) {
            trace("✗ Leitura do saldo: ${e.message}")
            BalanceRead.Unknown
        } finally {
            withContext(NonCancellable) { runCatching { s.close() } }   // CANCELAR
        }
    }

    private fun noteBalance(mb: Int) { AppState.lastBalanceMb.value = mb }

    private fun seen(label: String, screen: String) =
        trace("$label: ${screen.replace('\n', ' ').replace(Regex("\\s+"), " ").take(110)}")

    private suspend fun step(label: String, block: suspend () -> String): String =
        try {
            withTimeout(cfg.stepTimeoutMs) { block() }
        } catch (e: TimeoutCancellationException) {
            throw UssdException("timeout em '$label'", e)
        }

    private fun expect(screen: String, marker: String, label: String) {
        if (!screen.contains(marker, ignoreCase = true)) {
            throw UssdException("ecrã inesperado em '$label': ${screen.take(120)}")
        }
    }

    companion object {
        private val BALANCE = Regex("""saldo de dados:\s*(\d+(?:[.,]\d+)?)""", RegexOption.IGNORE_CASE)

        /**
         * "Atingiste o limite diario de 10 transferencias de megas. Tenta novamente amanha."
         * Sem acentos/maiúsculas; exige "limite" junto de "diario" ou "amanha" para não confundir com outros menus.
         */
        fun isLimitScreen(screen: String): Boolean {
            val n = Normalizer.normalize(screen, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()
            return n.contains("limite") && (n.contains("diario") || n.contains("amanha"))
        }

        fun parseBalanceMb(screen: String): Int? =
            BALANCE.find(screen)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()?.roundToInt()
    }
}

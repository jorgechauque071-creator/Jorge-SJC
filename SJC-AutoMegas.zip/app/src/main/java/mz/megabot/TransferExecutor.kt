package mz.megabot

import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * PENDING → EXECUTING → VERIFYING → DONE | FAILED | MANUAL
 *
 * Regra de ouro: a mensagem de erro da Vodacom NÃO é fiável (no vídeo mostrou
 * "não permitida" e debitou 100 MB). Só se repete uma transferência quando:
 *   (a) falhou antes de enviar o número do destinatário, ou
 *   (b) o saldo, lido duas vezes, prova que nada saiu.
 * Qualquer dúvida → MANUAL. Nunca repetir às cegas.
 */
class TransferExecutor(
    private val flows: VodacomFlows,
    private val store: OrderStore,
    private val cfg: TransferConfig,
    private val onFinished: suspend (Order) -> Unit = {},   // avisar servidor/bot
) {
    private enum class Verdict { DONE, NOT_EXECUTED, UNKNOWN }
    private data class Verification(val verdict: Verdict, val after: Int?)

    suspend fun process(orderId: String): Order {
        var o = store.get(orderId) ?: error("Ordem desconhecida: $orderId")

        if (o.status.isTerminal) return o                       // idempotente
        if (o.status == OrderStatus.EXECUTING || o.status == OrderStatus.VERIFYING) {
            return recover(o)                                   // app morreu a meio
        }

        validate(o)?.let { return finish(o, OrderStatus.FAILED, it) }
        if (store.countToday() >= cfg.dailyLimit) {
            return finish(o, OrderStatus.FAILED, "Limite diário de ${cfg.dailyLimit} transferências atingido")
        }

        while (true) {
            // Guardar ANTES de marcar: se a app morrer durante o USSD, sabemos que houve tentativa.
            o = save(o.copy(status = OrderStatus.EXECUTING, attempts = o.attempts + 1))

            val outcome = flows.submitTransfer(o.amountMb, o.recipient) { before ->
                o = save(o.copy(balanceBeforeMb = before))
            }

            when (outcome) {
                is TransferOutcome.NotSubmitted -> {
                    if (o.attempts >= cfg.maxAttempts || overBudget(o)) {
                        return finish(o, OrderStatus.FAILED, "Falhou antes do envio: ${outcome.reason}")
                    }
                    o = save(o.copy(status = OrderStatus.PENDING, note = "Retry: ${outcome.reason}"))
                    delay(retryDelay(o.attempts))
                }

                is TransferOutcome.Submitted -> {
                    o = save(o.copy(status = OrderStatus.VERIFYING, note = "Resposta Vodacom: ${outcome.finalMessage.take(160)}"))
                    val v = verify(o)
                    o = save(o.copy(balanceAfterMb = v.after))
                    when (v.verdict) {
                        Verdict.DONE -> return finish(o, OrderStatus.DONE, "Saldo confirma a transferência")
                        Verdict.UNKNOWN -> return finish(o, OrderStatus.MANUAL, "Não foi possível confirmar pelo saldo — verificar manualmente")
                        Verdict.NOT_EXECUTED -> {
                            if (o.attempts >= cfg.maxAttempts || overBudget(o)) {
                                return finish(o, OrderStatus.FAILED, "Saldo não mudou após ${o.attempts} tentativa(s): os megas não saíram")
                            }
                            o = save(o.copy(status = OrderStatus.PENDING, note = "Saldo não mudou; a repetir"))
                            delay(retryDelay(o.attempts))
                        }
                    }
                }
            }
        }
    }

    /** Depois de crash: só decide com base no saldo. Sem saldo inicial guardado → manual. */
    private suspend fun recover(o: Order): Order {
        if (o.balanceBeforeMb == null) {
            return finish(o, OrderStatus.MANUAL, "Reinício a meio sem saldo inicial — verificar manualmente")
        }
        val v = verify(o)
        val updated = save(o.copy(balanceAfterMb = v.after))
        return when (v.verdict) {
            Verdict.DONE -> finish(updated, OrderStatus.DONE, "Confirmado pelo saldo após reinício")
            Verdict.UNKNOWN -> finish(updated, OrderStatus.MANUAL, "Estado incerto após reinício — verificar manualmente")
            Verdict.NOT_EXECUTED ->
                if (updated.attempts >= cfg.maxAttempts || overBudget(updated)) {
                    finish(updated, OrderStatus.FAILED, "Saldo não mudou; tentativas esgotadas")
                } else {
                    save(updated.copy(status = OrderStatus.PENDING, note = "Saldo não mudou após reinício"))
                    process(updated.id)
                }
        }
    }

    /** Lê o saldo até 2 vezes (a Vodacom pode demorar a atualizar) e compara com o saldo inicial. */
    private suspend fun verify(o: Order): Verification {
        val before = o.balanceBeforeMb ?: return Verification(Verdict.UNKNOWN, null)
        var lastAfter: Int? = null
        repeat(2) { i ->
            delay(if (i == 0) cfg.verifyDelayMs else cfg.verifyRecheckDelayMs)
            val after = flows.readBalanceMb() ?: return Verification(Verdict.UNKNOWN, lastAfter)
            lastAfter = after
            val delta = before - after
            when {
                abs(delta - o.amountMb) <= cfg.toleranceMb -> return Verification(Verdict.DONE, after)
                delta > cfg.toleranceMb -> return Verification(Verdict.UNKNOWN, after)   // saiu valor estranho
                delta < -cfg.toleranceMb -> return Verification(Verdict.UNKNOWN, after)  // saldo subiu (recarga?)
                // senão delta ≈ 0: espera e volta a ler
            }
        }
        return Verification(Verdict.NOT_EXECUTED, lastAfter)
    }

    private fun validate(o: Order): String? = when {
        o.amountMb !in cfg.minMb..cfg.maxMb -> "Quantidade fora de ${cfg.minMb}–${cfg.maxMb} MB"
        !cfg.recipientRegex.matches(o.recipient) -> "Número de destinatário inválido"
        else -> null
    }

    private fun overBudget(o: Order): Boolean = System.currentTimeMillis() - o.createdAt > cfg.orderBudgetMs

    private fun retryDelay(attempt: Int): Long =
        cfg.retryDelaysMs.getOrElse(attempt - 1) { cfg.retryDelaysMs.last() }

    private suspend fun save(o: Order): Order {
        store.update(o)
        return o
    }

    private suspend fun finish(o: Order, status: OrderStatus, note: String): Order {
        val done = save(o.copy(status = status, note = note))
        onFinished(done)
        return done
    }
}

package mz.megabot

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Envia por SMS as respostas do bot aos clientes que mandaram o comprovativo por SMS.
 *  GET  /sms/saida?token=&telefone=   → {mensagens:[{id, para, texto}]}
 *  POST /sms/saida/ok {token, id}      → depois de enviar
 * Cada SMS gasta saldo do chip. Responde pelo mesmo chip em que o cliente escreveu.
 */
object SmsReplier {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).writeTimeout(8, TimeUnit.SECONDS).build()

    fun canSend(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** Bloqueia: chamar fora da thread principal. */
    fun poll(context: Context) {
        val ctx = context.applicationContext
        if (!canSend(ctx)) return
        Graph.init(ctx)
        val s = Graph.settings
        val base = BotLink.normalizeBase(s.serverUrl)
        val token = s.token.trim()
        if (base.isEmpty() || token.isEmpty()) return
        val url = (base + "/sms/saida").toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("token", token)
            ?.addQueryParameter("telefone", s.phoneId.trim())?.build() ?: return

        val msgs = try {
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.code != 200) return
                JSONObject(r.body?.string().orEmpty()).optJSONArray("mensagens")
            }
        } catch (e: Exception) { return } ?: return

        for (i in 0 until msgs.length()) {
            val m = msgs.getJSONObject(i)
            val id = m.getString("id")
            val para = m.getString("para")
            try {
                send(ctx, para, m.getString("texto"))
                AppState.log("SMS enviado ao cliente $para")
            } catch (e: Exception) {
                AppState.log("Não consegui enviar SMS a $para: ${e.message}")
                continue // o bot volta a entregar daqui a pouco
            }
            try {
                val ok = (base + "/sms/saida/ok").toHttpUrlOrNull() ?: continue
                val body = JSONObject().put("token", token).put("id", id)
                http.newCall(Request.Builder().url(ok).post(body.toString().toRequestBody("application/json".toMediaType())).build())
                    .execute().close()
            } catch (e: Exception) { /* se falhar, o bot reentrega; o cliente pode receber a mensagem repetida */ }
        }
    }

    private fun send(ctx: Context, to: String, text: String) {
        val sub = SmsForwarder.subFor(ctx, to)
        val sm = manager(ctx, sub)
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
    }

    @Suppress("DEPRECATION")
    private fun manager(ctx: Context, subId: Int): SmsManager {
        if (Build.VERSION.SDK_INT >= 31) {
            val base = ctx.getSystemService(SmsManager::class.java)
            return if (subId >= 0) base.createForSubscriptionId(subId) else base
        }
        return if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
    }
}

package mz.megabot

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri

/**
 * Rede de segurança: alguns telemóveis (poupança de bateria, "arranque automático" desligado) não entregam o
 * SMS à app em tempo real. Por isso, com o serviço ligado, a app também vai à caixa de entrada buscar os SMS
 * que ainda não tratou. Não repete os que o receiver já tratou (guardamos uma lista dos já vistos).
 */
object SmsInbox {
    private const val PREFS = "sjc_sms_scan"
    private const val K_LAST = "last_date"
    private const val K_SEEN = "seen"
    private const val MAX_SEEN = 300
    private const val FRESH_MS = 20_000L                 // os últimos 20 s ficam para o receiver (evita tratar duas vezes)
    private const val FIRST_WINDOW_MS = 15 * 60 * 1000L  // 1.ª vez: só olha para os últimos 15 min
    private val lock = Any()
    private val INBOX: Uri = Uri.parse("content://sms/inbox")

    private class Row(val address: String, val body: String, val date: Long, val subId: Int)

    fun canRead(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun key(sender: String, text: String): String = sender.trim() + "|" + text.trim().hashCode()

    private fun seenList(sp: SharedPreferences): MutableList<String> =
        (sp.getString(K_SEEN, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()

    private fun saveSeen(sp: SharedPreferences, list: List<String>) {
        val l = if (list.size > MAX_SEEN) list.takeLast(MAX_SEEN) else list
        sp.edit().putString(K_SEEN, l.joinToString("\n")).apply()
    }

    /** Marca um SMS como já tratado (chamado por quem o trata). */
    fun markSeen(ctx: Context, sender: String, text: String) {
        synchronized(lock) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val list = seenList(sp)
            val k = key(sender, text)
            if (!list.contains(k)) {
                list.add(k)
                saveSeen(sp, list)
            }
        }
    }

    private fun query(ctx: Context, withSub: Boolean, last: Long, now: Long, out: MutableList<Row>) {
        val cols = if (withSub) arrayOf("address", "body", "date", "sub_id") else arrayOf("address", "body", "date")
        val cursor = ctx.contentResolver.query(
            INBOX, cols, "date > ? AND date <= ?",
            arrayOf(last.toString(), (now - FRESH_MS).toString()), "date ASC"
        ) ?: return
        cursor.use { c ->
            while (c.moveToNext()) {
                out.add(Row(c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2), if (withSub) c.getInt(3) else -1))
            }
        }
    }

    /** Bloqueia: chamar fora da thread principal. */
    fun scan(context: Context) {
        val ctx = context.applicationContext
        if (!canRead(ctx)) return
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        var last = sp.getLong(K_LAST, 0L)
        if (last == 0L) last = now - FIRST_WINDOW_MS

        val rows = ArrayList<Row>()
        try {
            query(ctx, true, last, now, rows)
        } catch (e: Exception) {
            rows.clear()
            try {
                query(ctx, false, last, now, rows)
            } catch (e2: Exception) {
                AppState.log("Não consegui ler a caixa de SMS: ${e2.message}")
                return
            }
        }

        var newest = last
        for (r in rows) {
            val seen = synchronized(lock) { seenList(sp).contains(key(r.address, r.body)) }
            if (!seen) {
                AppState.log("SMS apanhado na caixa de entrada (o Android não o entregou em tempo real): ${r.address}")
                SmsForwarder.onSms(ctx, r.address, r.body, r.subId)
            }
            if (r.date > newest) newest = r.date
        }
        sp.edit().putLong(K_LAST, newest).apply()
    }
}

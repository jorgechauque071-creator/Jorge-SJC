package mz.megabot

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri

/**
 * Rede de segurança: alguns telemóveis (poupança de bateria, "arranque automático" desligado) não entregam o
 * SMS à app em tempo real. Por isso, com o serviço ligado, a app também vai à caixa de entrada buscar os SMS
 * que ainda não tratou.
 *
 * Não depende da HORA dos SMS (a hora do e-Mola e a do M-Pesa podem vir desencontradas): olha para os
 * últimos SMS da caixa e trata os que ainda não viu. Para não tratar duas vezes um SMS que o receiver já
 * tratou, só reenvia um SMS novo se ele continuar por tratar na leitura seguinte (~12 s depois).
 */
object SmsInbox {
    private const val PREFS = "sjc_sms_scan"
    private const val K_SEEN = "seen"
    private const val K_INIT = "init"
    private const val MAX_SEEN = 400
    private const val LAST_ROWS = 60
    private const val FIRST_FORWARD_MS = 10 * 60 * 1000L // na 1.ª vez só reenvia o que tem menos de 10 min
    private const val CONFIRM_MS = 8_000L                // só reenvia se estiver por tratar há mais de 8 s
    private val lock = Any()
    private val firstSeen = HashMap<String, Long>()
    private val INBOX: Uri = Uri.parse("content://sms/inbox")

    private class Row(val address: String, val body: String, val date: Long, val subId: Int)

    fun canRead(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun key(sender: String, text: String): String = sender.trim() + "|" + text.trim().hashCode()

    private fun seenList(sp: SharedPreferences): MutableList<String> =
        (sp.getString(K_SEEN, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()

    private fun saveSeen(sp: SharedPreferences, list: List<String>) {
        val l = if (list.size > MAX_SEEN) list.takeLast(MAX_SEEN) else list
        sp.edit().putString(K_SEEN, l.joinToString("\n")).apply()
    }

    /** Marca um SMS como já tratado (chamado por quem o trata). */
    fun markSeen(ctx: Context, sender: String, text: String) {
        synchronized(lock) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val list = seenList(sp)
            val k = key(sender, text)
            if (!list.contains(k)) {
                list.add(k)
                saveSeen(sp, list)
            }
        }
    }

    private fun isSeen(ctx: Context, sender: String, text: String): Boolean = synchronized(lock) {
        seenList(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)).contains(key(sender, text))
    }

    /** modo 0: sub_id + LIMIT; modo 1: sem sub_id + LIMIT; modo 2: sem sub_id, últimas 24 h, sem LIMIT. */
    private fun query(ctx: Context, mode: Int, out: MutableList<Row>) {
        val withSub = mode == 0
        val cols = if (withSub) arrayOf("address", "body", "date", "sub_id") else arrayOf("address", "body", "date")
        val cursor = if (mode <= 1) {
            ctx.contentResolver.query(INBOX, cols, null, null, "_id DESC LIMIT $LAST_ROWS")
        } else {
            val desde = (System.currentTimeMillis() - 24 * 60 * 60 * 1000L).toString()
            ctx.contentResolver.query(INBOX, cols, "date > ?", arrayOf(desde), "date DESC")
        } ?: return
        cursor.use { c ->
            while (c.moveToNext()) {
                out.add(Row(c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2), if (withSub) c.getInt(3) else -1))
            }
        }
    }

    /** Bloqueia: chamar fora da thread principal. */
    fun scan(context: Context) {
        val ctx = context.applicationContext
        if (!canRead(ctx)) return
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()

        val rows = ArrayList<Row>()
        var ok = false
        var erro: Exception? = null
        for (mode in 0..2) {
            try {
                rows.clear()
                query(ctx, mode, rows)
                ok = true
                break
            } catch (e: Exception) {
                erro = e
            }
        }
        if (!ok) {
            AppState.log("Não consegui ler a caixa de SMS: ${erro?.message}")
            return
        }
        rows.reverse() // do mais antigo para o mais recente

        val firstRun = !sp.getBoolean(K_INIT, false)
        for (r in rows) {
            if (isSeen(ctx, r.address, r.body)) continue
            val k = key(r.address, r.body)
            if (firstRun && now - r.date > FIRST_FORWARD_MS) {
                markSeen(ctx, r.address, r.body) // já existia antes de a app começar a vigiar: ignora
                continue
            }
            val desde = firstSeen.getOrPut(k) { now }
            if (now - desde < CONFIRM_MS) continue // dá tempo ao receiver para o tratar primeiro
            firstSeen.remove(k)
            AppState.log("SMS apanhado na caixa de entrada (o Android não o entregou em tempo real): ${r.address}")
            SmsForwarder.onSms(ctx, r.address, r.body, r.subId)
        }
        if (firstRun) sp.edit().putBoolean(K_INIT, true).apply()
    }
}

package mz.megabot

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * "Cartão cheio hoje": a Vodacom já limitou as transferências de megas deste cartão (mensagem de limite diário).
 * Vale até à meia-noite de Maputo. Enquanto estiver marcado, a app recusa os pedidos sem abrir o USSD
 * e o bot passa-os ao telefone seguinte.
 */
object DayLimit {
    /** Prefixo da nota da ordem: é por ele que o BotLink diz ao bot que foi por causa do limite. */
    const val NOTE = "[LIMITE] "

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Africa/Maputo") }.format(Date())

    fun reachedToday(): Boolean = Graph.settings.limitReachedDay == today()

    fun markReached() {
        Graph.settings.limitReachedDay = today()
    }

    fun clear() {
        Graph.settings.limitReachedDay = ""
    }
}

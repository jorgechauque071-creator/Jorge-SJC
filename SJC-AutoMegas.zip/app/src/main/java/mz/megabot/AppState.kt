package mz.megabot

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { OFF, CONNECTING, ONLINE }

/** Estado observado pela interface. */
object AppState {
    val conn = MutableStateFlow(Conn.OFF)
    val serviceRunning = MutableStateFlow(false)
    val lastBalanceMb = MutableStateFlow<Int?>(null)
    val orders = MutableStateFlow<List<Order>>(emptyList())
    val logLines = MutableStateFlow<List<String>>(emptyList())

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(msg: String) {
        val line = "${fmt.format(Date())}  $msg"
        logLines.update { (listOf(line) + it).take(60) }
    }
}

/** Instâncias partilhadas entre Activity, serviço e receivers. */
object Graph {
    lateinit var store: SqliteOrderStore
    lateinit var settings: AppSettings
    private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        settings = AppSettings(app)
        store = SqliteOrderStore(app)
        store.onChanged = { refreshOrders() }
        ready = true
        refreshOrders()
    }

    fun refreshOrders() {
        scope.launch { AppState.orders.value = store.recent() }
    }
}

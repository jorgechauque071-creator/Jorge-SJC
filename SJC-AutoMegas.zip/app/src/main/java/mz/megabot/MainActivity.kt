package mz.megabot

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SubscriptionManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private val Lime = Color(0xFF84FF1A)
private val Panel = Color(0xFF0E140E)
private val Muted = Color(0xFF9AA59A)
private val Red = Color(0xFFFF5252)
private val Amber = Color(0xFFFFB300)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Graph.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Lime, onPrimary = Color.Black,
                    background = Color.Black, surface = Panel, onSurface = Color(0xFFE8F0E8),
                )
            ) {
                MainScreen(tick) { tick++ }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

private fun has(ctx: Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

private fun accessibilityEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
    return s.contains(ctx.packageName) && s.contains(UssdAccessibilityService::class.java.simpleName)
}

@SuppressLint("MissingPermission")
private fun listSims(ctx: Context): List<Pair<Int, String>> = try {
    val sm = ctx.getSystemService(SubscriptionManager::class.java)
    sm.activeSubscriptionInfoList.orEmpty().map { it.subscriptionId to "SIM ${it.simSlotIndex + 1} · ${it.carrierName}" }
} catch (e: Exception) {
    emptyList()
}

@Composable
fun MainScreen(tick: Int, bump: () -> Unit) {
    val ctx = LocalContext.current
    val settings = Graph.settings
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf(settings.serverUrl) }
    var token by remember { mutableStateOf(settings.token) }
    var showToken by remember { mutableStateOf(false) }
    var subId by remember { mutableIntStateOf(settings.subscriptionId) }
    var phoneId by remember { mutableStateOf(settings.phoneId) }
    var limitText by remember { mutableStateOf(settings.dailyLimit.toString()) }
    var testMsg by remember { mutableStateOf("") }

    val conn by AppState.conn.collectAsState()
    val running by AppState.serviceRunning.collectAsState()
    val orders by AppState.orders.collectAsState()
    val logs by AppState.logLines.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { bump() }

    val hasCall = remember(tick) { has(ctx, Manifest.permission.CALL_PHONE) }
    val hasState = remember(tick) { has(ctx, Manifest.permission.READ_PHONE_STATE) }
    val hasNotif = remember(tick) { Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS) }
    val accessOn = remember(tick) { accessibilityEnabled(ctx) }
    val battery = remember(tick) { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) }
    val sims = remember(tick) { listSims(ctx) }

    val overlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val urlOk = BotLink.normalizeBase(url).length > 10
    val phoneOk = phoneId.trim().matches(Regex("[A-Za-z0-9_-]{1,24}"))
    val ready = urlOk && token.isNotBlank() && phoneOk && hasCall && accessOn

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Cabeçalho
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.logo), contentDescription = "S.J.C",
                modifier = Modifier.size(76.dp).clip(RoundedCornerShape(50)), contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text("S.J.C", fontSize = 26.sp, fontWeight = FontWeight.Black, color = Lime)
                Text("Auto de Megas", fontSize = 15.sp, color = Color.White)
                val (label, color) = when {
                    !running -> "Parado" to Muted
                    conn == Conn.ONLINE -> "Online" to Lime
                    else -> "A ligar…" to Amber
                }
                Text("● $label", color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }

        // Ligação ao bot
        Section("Ligação ao bot") {
            OutlinedTextField(
                value = url, onValueChange = { url = it; settings.serverUrl = it.trim() },
                label = { Text("Endereço do bot (ex.: http://192.168.1.10:20236)") }, singleLine = true,
                isError = url.isNotBlank() && !urlOk, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                enabled = !running,
            )
            OutlinedTextField(
                value = token, onValueChange = { token = it; settings.token = it.trim() },
                label = { Text("Token (APP_TOKEN do config.js)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Ocultar" else "Ver") } },
                enabled = !running,
            )
            OutlinedTextField(
                value = phoneId, onValueChange = { phoneId = it; settings.phoneId = it.trim() },
                label = { Text("ID deste telefone (tel1, tel2…)") }, singleLine = true,
                isError = !phoneOk, modifier = Modifier.fillMaxWidth(), enabled = !running,
            )
            OutlinedButton(
                onClick = {
                    testMsg = "A testar…"
                    scope.launch { testMsg = BotLink.testConnection(url, token) }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Testar ligação ao bot") }
            if (testMsg.isNotBlank()) Text(testMsg, color = if (testMsg.startsWith("Ligação OK")) Lime else Amber, fontSize = 12.sp)
        }

        // Limite de transferências
        Section("Limite de transferências por dia") {
            OutlinedTextField(
                value = limitText,
                onValueChange = { v ->
                    val digits = v.filter { it.isDigit() }.take(4)
                    limitText = digits
                    digits.toIntOrNull()?.takeIf { it >= 1 }?.let { settings.dailyLimit = it }
                },
                label = { Text("Máximo de transferências por dia") }, singleLine = true,
                isError = (limitText.toIntOrNull() ?: 0) < 1, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                enabled = !running,
            )
            Text("Aplica-se ao iniciar o serviço (pára e volta a iniciar para mudar).", color = Muted, fontSize = 12.sp)
        }

        // SIM
        Section("Chip (SIM) a usar") {
            if (!hasState) {
                Text("Dá a permissão de telefone para listar os chips.", color = Muted, fontSize = 13.sp)
            } else {
                SimRow("Automático (chip predefinido)", subId == -1, !running) { subId = -1; settings.subscriptionId = -1 }
                sims.forEach { (id, name) ->
                    SimRow(name, subId == id, !running) { subId = id; settings.subscriptionId = id }
                }
            }
        }

        // Permissões
        Section("Permissões") {
            val need = buildList {
                add(Manifest.permission.CALL_PHONE); add(Manifest.permission.READ_PHONE_STATE)
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }.toTypedArray()
            PermRow("Chamadas, telefone e notificações", hasCall && hasState && hasNotif) {
                permLauncher.launch(need)
            }
            PermRow("Acessibilidade (ler/responder USSD)", accessOn) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            PermRow("Sobrepor a outras apps (acordar o ecrã)", overlay) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            PermRow("Sem otimização de bateria", battery) {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        // Iniciar / parar
        Button(
            onClick = {
                if (running) {
                    settings.enabled = false
                    ctx.startService(Intent(ctx, MacroService::class.java).setAction(MacroService.ACTION_STOP))
                } else {
                    settings.serverUrl = url.trim(); settings.token = token.trim(); settings.phoneId = phoneId.trim(); settings.subscriptionId = subId
                    settings.enabled = true
                    ContextCompat.startForegroundService(ctx, Intent(ctx, MacroService::class.java))
                }
            },
            enabled = running || ready,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (running) Red else Lime),
            shape = RoundedCornerShape(14.dp),
        ) { Text(if (running) "PARAR" else "INICIAR", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

        if (!running && !ready) {
            Text("Para iniciar: preenche endereço, token e ID do telefone, dá a permissão de chamadas e ativa a acessibilidade.", color = Muted, fontSize = 12.sp)
        }

        OutlinedButton(
            onClick = {
                scope.launch(Dispatchers.Default) {
                    AppState.log("Teste: a ler o saldo…")
                    val flows = VodacomFlows(AccessibilitySessionFactory(ctx.applicationContext), TransferConfig(subscriptionId = subId)) { AppState.log(it) }
                    val mb = flows.readBalanceMb()
                    AppState.log(if (mb != null) "Teste OK: saldo $mb MB" else "Teste falhou (ver acessibilidade/permissões)")
                }
            },
            enabled = !running && hasCall && accessOn,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Testar USSD (ler saldo de dados)") }

        // Ordens
        Section("Ordens recentes") {
            if (orders.isEmpty()) Text("Ainda sem ordens.", color = Muted, fontSize = 13.sp)
            orders.take(30).forEach { o ->
                val color = when (o.status) {
                    OrderStatus.DONE -> Lime
                    OrderStatus.FAILED -> Red
                    OrderStatus.MANUAL -> Amber
                    else -> Muted
                }
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${o.amountMb} MB → ${o.recipient}", fontWeight = FontWeight.Medium)
                        Text(o.status.name, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Text("#${o.id.take(10)} · tentativas: ${o.attempts}", color = Muted, fontSize = 11.sp)
                    o.note?.let { Text(it, color = Muted, fontSize = 11.sp) }
                }
            }
        }

        // Registo
        Section("Registo") {
            if (logs.isEmpty()) Text("—", color = Muted, fontSize = 12.sp)
            logs.take(25).forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Muted) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Lime, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            content()
        }
    }
}

@Composable
private fun SimRow(name: String, selected: Boolean, enabled: Boolean, onSelect: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onSelect, enabled = enabled)
        Text(name, fontSize = 14.sp)
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("${if (ok) "✓" else "✗"}  $label", color = if (ok) Lime else Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (!ok) TextButton(onClick = onFix) { Text("Ativar") }
    }
}

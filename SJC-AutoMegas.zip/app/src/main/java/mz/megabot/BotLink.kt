package mz.megabot

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Fala com o bot (docs/API_APP.md do bot):
 *   GET  /pedidos/proximo?token=&telefone=&saldo=   → 204 sem trabalho | 200 {id, mb, numero}
 *   POST /pedidos/resultado {token,id,telefone,estado,texto,saldoAntes,saldoDepois}
 * Pergunta a cada ~3 s (isso também é o "estou online"). Faz um pedido de cada vez.
 */
class BotLink(
    private val scope: CoroutineScope,
    private val settings: AppSettings,
    private val store: SqliteOrderStore,
    private val executor: TransferExecutor,
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private var loop: Job? = null

    private sealed interface Poll {
        data object None : Poll
        data object BadToken : Poll
        data class Got(val id: String, val mb: Int, val numero: String) : Poll
    }

    fun start() {
        loop = scope.launch {
            var failures = 0
            try { recoverUnfinished(); resendUnreported() } catch (e: CancellationException) { throw e } catch (e: Exception) { AppState.log("Recuperação: ${e.message}") }
            while (isActive) {
                try {
                    when (val r = poll()) {
                        is Poll.None -> {}
                        is Poll.BadToken -> {
                            AppState.conn.value = Conn.CONNECTING
                            AppState.log("O bot recusou o token (401). Confere o token na app e no config.js")
                            delay(10_000)
                            continue
                        }
                        is Poll.Got -> handleOrder(r)
                    }
                    failures = 0
                    AppState.conn.value = Conn.ONLINE
                    resendUnreported()
                    delay(POLL_MS)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures++
                    AppState.conn.value = Conn.CONNECTING
                    if (failures == 1 || failures % 10 == 0) AppState.log("Sem ligação ao bot: ${e.message}")
                    delay(minOf(3_000L * failures, 15_000L))
                }
            }
        }
    }

    fun stop() {
        loop?.cancel()
        AppState.conn.value = Conn.OFF
    }

    // ---------- pedidos ----------

    private suspend fun poll(): Poll = withContext(Dispatchers.IO) {
        val url = endpoint("/pedidos/proximo")?.newBuilder()
            ?.addQueryParameter("token", settings.token.trim())
            ?.addQueryParameter("telefone", settings.phoneId.trim())
            ?.apply { AppState.lastBalanceMb.value?.let { addQueryParameter("saldo", it.toString()) } }
            ?.build() ?: throw IllegalStateException("endereço do bot inválido")
        http.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            when (resp.code) {
                204 -> Poll.None
                401 -> Poll.BadToken
                200 -> {
                    val j = JSONObject(resp.body?.string().orEmpty())
                    Poll.Got(
                        id = j.getString("id"),
                        mb = j.get("mb").toString().filter { it.isDigit() }.toInt(),
                        numero = j.get("numero").toString().filter { it.isDigit() }.takeLast(9),
                    )
                }
                else -> throw IllegalStateException("HTTP ${resp.code}")
            }
        }
    }

    private suspend fun handleOrder(g: Poll.Got) {
        AppState.log("Pedido ${g.id}: ${g.mb} MB → ${g.numero}")
        val existing = store.get(g.id)
        if (existing == null) store.insertIfAbsent(Order(id = g.id, recipient = g.numero, amountMb = g.mb))
        val done = try {
            executor.process(g.id)           // idempotente: se já terminou, devolve o resultado guardado
        } finally {
            ScreenWaker.release()
        }
        reportResult(done)
    }

    /** Depois de reiniciar a meio: acaba o que ficou começado, mas nunca começa do zero uma ordem velha. */
    private suspend fun recoverUnfinished() {
        for (o in store.unfinished()) {
            val stale = o.status == OrderStatus.PENDING && o.attempts == 0 &&
                System.currentTimeMillis() - o.createdAt > 150_000L
            if (stale) {
                store.update(o.copy(status = OrderStatus.FAILED, note = "Ordem expirada: nunca foi executada"))
                continue
            }
            AppState.log("A retomar pedido ${o.id}")
            try { executor.process(o.id) } finally { ScreenWaker.release() }
        }
    }

    // ---------- resultados ----------

    suspend fun reportResult(o: Order) {
        val estado = when (o.status) {
            OrderStatus.DONE -> "ok"
            OrderStatus.FAILED -> "falhou"
            else -> "verificar"
        }
        val body = JSONObject()
            .put("token", settings.token.trim())
            .put("id", o.id)
            .put("telefone", settings.phoneId.trim())
            .put("estado", estado)
            .put("texto", o.note ?: "")
        o.balanceBeforeMb?.let { body.put("saldoAntes", it) }     // omitido se desconhecido (o bot leria 0)
        o.balanceAfterMb?.let { body.put("saldoDepois", it) }

        val url = endpoint("/pedidos/resultado") ?: return
        val code = try {
            withContext(Dispatchers.IO) {
                val req = Request.Builder().url(url)
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { it.code }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppState.log("Resultado do pedido ${o.id} por entregar (${e.message})")
            return
        }
        if (code == 200) {
            store.markReported(o.id)
            AppState.log("Resultado enviado: ${o.id} → $estado")
        } else {
            AppState.log("Bot respondeu HTTP $code ao resultado de ${o.id}; vou tentar de novo")
        }
    }

    private suspend fun resendUnreported() {
        store.unreported().forEach { reportResult(it) }
    }

    private fun endpoint(path: String) = normalizeBase(settings.serverUrl).plus(path).toHttpUrlOrNull()

    companion object {
        const val POLL_MS = 3_000L

        fun normalizeBase(raw: String): String {
            val s = raw.trim().trimEnd('/')
            if (s.isEmpty()) return ""
            return if (s.startsWith("http://") || s.startsWith("https://")) s else "http://$s"
        }

        /** Verifica endereço + token sem consumir pedidos (GET /telefones). Devolve uma frase para mostrar. */
        suspend fun testConnection(baseRaw: String, token: String): String = withContext(Dispatchers.IO) {
            val client = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
            val url = (normalizeBase(baseRaw) + "/telefones").toHttpUrlOrNull()
                ?.newBuilder()?.addQueryParameter("token", token.trim())?.build()
                ?: return@withContext "Endereço inválido"
            try {
                client.newCall(Request.Builder().url(url).build()).execute().use {
                    when (it.code) {
                        200 -> "Ligação OK: o bot respondeu e o token está certo"
                        401 -> "O bot respondeu, mas o token está errado"
                        else -> "O bot respondeu HTTP ${it.code}"
                    }
                }
            } catch (e: Exception) {
                "Sem ligação: ${e.message}"
            }
        }
    }
}
